using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticBallsNumber : MonoBehaviour
{

    public static int ballsNum;

}
